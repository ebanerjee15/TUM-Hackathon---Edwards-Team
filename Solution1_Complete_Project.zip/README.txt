Solution 1 local demonstrator

Requires Python 3.10+ (recommended 3.12).
From inside the hbn_twin folder:
py -3.12 -m venv .venv312
.\.venv312\Scripts\python.exe -m pip install -r requirements.txt
.\.venv312\Scripts\python.exe check_model.py
.\.venv312\Scripts\python.exe check_controller.py
.\.venv312\Scripts\python.exe -m streamlit run app.py

Then open http://localhost:8501 in your browser.
